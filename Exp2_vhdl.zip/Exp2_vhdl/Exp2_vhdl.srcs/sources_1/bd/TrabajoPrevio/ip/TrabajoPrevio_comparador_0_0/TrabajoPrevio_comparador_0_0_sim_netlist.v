// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.1 (win64) Build 2902540 Wed May 27 19:54:49 MDT 2020
// Date        : Fri Sep  4 16:43:25 2026
// Host        : TROND-ENVYX360 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/linnh/LabAD/Exp2_vhdl/Exp2_vhdl.srcs/sources_1/bd/TrabajoPrevio/ip/TrabajoPrevio_comparador_0_0/TrabajoPrevio_comparador_0_0_sim_netlist.v
// Design      : TrabajoPrevio_comparador_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "TrabajoPrevio_comparador_0_0,comparador,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "comparador,Vivado 2020.1" *) 
(* NotValidForBitStream *)
module TrabajoPrevio_comparador_0_0
   (positivo,
    negativo,
    comparacion);
  input [7:0]positivo;
  input [7:0]negativo;
  output comparacion;

  wire comparacion;
  wire [7:0]negativo;
  wire [7:0]positivo;

  TrabajoPrevio_comparador_0_0_comparador U0
       (.comparacion(comparacion),
        .negativo(negativo),
        .positivo(positivo));
endmodule

(* ORIG_REF_NAME = "comparador" *) 
module TrabajoPrevio_comparador_0_0_comparador
   (comparacion,
    positivo,
    negativo);
  output comparacion;
  input [7:0]positivo;
  input [7:0]negativo;

  wire comparacion;
  wire comparacion_INST_0_i_1_n_0;
  wire comparacion_INST_0_i_2_n_0;
  wire comparacion_INST_0_i_3_n_0;
  wire comparacion_INST_0_i_4_n_0;
  wire comparacion_INST_0_i_5_n_0;
  wire comparacion_INST_0_i_6_n_0;
  wire comparacion_INST_0_i_7_n_0;
  wire comparacion_INST_0_i_8_n_0;
  wire comparacion_INST_0_n_1;
  wire comparacion_INST_0_n_2;
  wire comparacion_INST_0_n_3;
  wire [7:0]negativo;
  wire [7:0]positivo;
  wire [3:0]NLW_comparacion_INST_0_O_UNCONNECTED;

  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 comparacion_INST_0
       (.CI(1'b0),
        .CO({comparacion,comparacion_INST_0_n_1,comparacion_INST_0_n_2,comparacion_INST_0_n_3}),
        .CYINIT(1'b0),
        .DI({comparacion_INST_0_i_1_n_0,comparacion_INST_0_i_2_n_0,comparacion_INST_0_i_3_n_0,comparacion_INST_0_i_4_n_0}),
        .O(NLW_comparacion_INST_0_O_UNCONNECTED[3:0]),
        .S({comparacion_INST_0_i_5_n_0,comparacion_INST_0_i_6_n_0,comparacion_INST_0_i_7_n_0,comparacion_INST_0_i_8_n_0}));
  LUT4 #(
    .INIT(16'h2F02)) 
    comparacion_INST_0_i_1
       (.I0(positivo[6]),
        .I1(negativo[6]),
        .I2(negativo[7]),
        .I3(positivo[7]),
        .O(comparacion_INST_0_i_1_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    comparacion_INST_0_i_2
       (.I0(positivo[4]),
        .I1(negativo[4]),
        .I2(negativo[5]),
        .I3(positivo[5]),
        .O(comparacion_INST_0_i_2_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    comparacion_INST_0_i_3
       (.I0(positivo[2]),
        .I1(negativo[2]),
        .I2(negativo[3]),
        .I3(positivo[3]),
        .O(comparacion_INST_0_i_3_n_0));
  LUT4 #(
    .INIT(16'h2F02)) 
    comparacion_INST_0_i_4
       (.I0(positivo[0]),
        .I1(negativo[0]),
        .I2(negativo[1]),
        .I3(positivo[1]),
        .O(comparacion_INST_0_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    comparacion_INST_0_i_5
       (.I0(positivo[6]),
        .I1(negativo[6]),
        .I2(positivo[7]),
        .I3(negativo[7]),
        .O(comparacion_INST_0_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    comparacion_INST_0_i_6
       (.I0(positivo[4]),
        .I1(negativo[4]),
        .I2(positivo[5]),
        .I3(negativo[5]),
        .O(comparacion_INST_0_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    comparacion_INST_0_i_7
       (.I0(positivo[2]),
        .I1(negativo[2]),
        .I2(positivo[3]),
        .I3(negativo[3]),
        .O(comparacion_INST_0_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    comparacion_INST_0_i_8
       (.I0(positivo[0]),
        .I1(negativo[0]),
        .I2(positivo[1]),
        .I3(negativo[1]),
        .O(comparacion_INST_0_i_8_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
