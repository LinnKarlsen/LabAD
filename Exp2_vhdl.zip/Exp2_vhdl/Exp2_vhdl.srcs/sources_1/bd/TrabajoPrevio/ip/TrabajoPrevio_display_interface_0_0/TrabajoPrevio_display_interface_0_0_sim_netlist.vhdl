-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.1 (win64) Build 2902540 Wed May 27 19:54:49 MDT 2020
-- Date        : Mon Sep  7 11:46:29 2026
-- Host        : TROND-ENVYX360 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/linnh/LabAD/Exp2_vhdl/Exp2_vhdl.srcs/sources_1/bd/TrabajoPrevio/ip/TrabajoPrevio_display_interface_0_0/TrabajoPrevio_display_interface_0_0_sim_netlist.vhdl
-- Design      : TrabajoPrevio_display_interface_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity TrabajoPrevio_display_interface_0_0_display_interface is
  port (
    an : out STD_LOGIC_VECTOR ( 3 downto 0 );
    seg : out STD_LOGIC_VECTOR ( 6 downto 0 );
    digit_index : in STD_LOGIC_VECTOR ( 2 downto 0 );
    digit_value : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of TrabajoPrevio_display_interface_0_0_display_interface : entity is "display_interface";
end TrabajoPrevio_display_interface_0_0_display_interface;

architecture STRUCTURE of TrabajoPrevio_display_interface_0_0_display_interface is
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \an[0]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \an[1]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \an[2]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \an[3]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \seg[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg[1]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg[2]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg[3]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg[4]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \seg[5]_INST_0\ : label is "soft_lutpair2";
begin
\an[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => digit_index(2),
      I1 => digit_index(0),
      I2 => digit_index(1),
      O => an(0)
    );
\an[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BF"
    )
        port map (
      I0 => digit_index(2),
      I1 => digit_index(0),
      I2 => digit_index(1),
      O => an(1)
    );
\an[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => digit_index(1),
      I1 => digit_index(0),
      I2 => digit_index(2),
      O => an(2)
    );
\an[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => digit_index(0),
      I1 => digit_index(2),
      I2 => digit_index(1),
      O => an(3)
    );
\seg[0]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA9C"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(2),
      I2 => digit_value(0),
      I3 => digit_value(1),
      O => seg(0)
    );
\seg[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"ACE8"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(2),
      I2 => digit_value(1),
      I3 => digit_value(0),
      O => seg(1)
    );
\seg[2]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAB0"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(0),
      I2 => digit_value(1),
      I3 => digit_value(2),
      O => seg(2)
    );
\seg[3]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EABC"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(2),
      I2 => digit_value(0),
      I3 => digit_value(1),
      O => seg(3)
    );
\seg[4]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFB8"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(1),
      I2 => digit_value(2),
      I3 => digit_value(0),
      O => seg(4)
    );
\seg[5]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F9B8"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(2),
      I2 => digit_value(1),
      I3 => digit_value(0),
      O => seg(5)
    );
\seg[6]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EAA5"
    )
        port map (
      I0 => digit_value(3),
      I1 => digit_value(0),
      I2 => digit_value(2),
      I3 => digit_value(1),
      O => seg(6)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity TrabajoPrevio_display_interface_0_0 is
  port (
    digit_value : in STD_LOGIC_VECTOR ( 3 downto 0 );
    digit_index : in STD_LOGIC_VECTOR ( 2 downto 0 );
    decimal_point : in STD_LOGIC;
    seg : out STD_LOGIC_VECTOR ( 6 downto 0 );
    dp : out STD_LOGIC;
    an : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of TrabajoPrevio_display_interface_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of TrabajoPrevio_display_interface_0_0 : entity is "TrabajoPrevio_display_interface_0_0,display_interface,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of TrabajoPrevio_display_interface_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of TrabajoPrevio_display_interface_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of TrabajoPrevio_display_interface_0_0 : entity is "display_interface,Vivado 2020.1";
end TrabajoPrevio_display_interface_0_0;

architecture STRUCTURE of TrabajoPrevio_display_interface_0_0 is
begin
U0: entity work.TrabajoPrevio_display_interface_0_0_display_interface
     port map (
      an(3 downto 0) => an(3 downto 0),
      digit_index(2 downto 0) => digit_index(2 downto 0),
      digit_value(3 downto 0) => digit_value(3 downto 0),
      seg(6 downto 0) => seg(6 downto 0)
    );
dp_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => decimal_point,
      O => dp
    );
end STRUCTURE;
