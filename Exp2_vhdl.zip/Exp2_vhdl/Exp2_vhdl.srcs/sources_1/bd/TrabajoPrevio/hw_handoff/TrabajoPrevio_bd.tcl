
################################################################
# This is a generated script based on design: TrabajoPrevio
#
# Though there are limitations about the generated script,
# the main purpose of this utility is to make learning
# IP Integrator Tcl commands easier.
################################################################

namespace eval _tcl {
proc get_script_folder {} {
   set script_path [file normalize [info script]]
   set script_folder [file dirname $script_path]
   return $script_folder
}
}
variable script_folder
set script_folder [_tcl::get_script_folder]

################################################################
# Check if script is running in correct Vivado version.
################################################################
set scripts_vivado_version 2020.1
set current_vivado_version [version -short]

if { [string first $scripts_vivado_version $current_vivado_version] == -1 } {
   puts ""
   catch {common::send_gid_msg -ssname BD::TCL -id 2041 -severity "ERROR" "This script was generated using Vivado <$scripts_vivado_version> and is being run in <$current_vivado_version> of Vivado. Please run the script in Vivado <$scripts_vivado_version> then open the design in Vivado <$current_vivado_version>. Upgrade the design by running \"Tools => Report => Report IP Status...\", then run write_bd_tcl to create an updated script."}

   return 1
}

################################################################
# START
################################################################

# To test this script, run the following commands from Vivado Tcl console:
# source TrabajoPrevio_script.tcl


# The design that will be created by this Tcl script contains the following 
# module references:
# RX_uart, comparador, display_interface, display_manager, divisor_de_clk_con_switch, divisor_de_clk_display, divisor_de_clk_sierra, divisor_de_clk_uart, generador_de_sierra, generador_de_sinusoide, wave_mux

# Please add the sources of those modules before sourcing this Tcl script.

# If there is no project opened, this script will create a
# project, but make sure you do not have an existing project
# <./myproj/project_1.xpr> in the current working folder.

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
   create_project project_1 myproj -part xc7a35tcpg236-1
   set_property BOARD_PART digilentinc.com:basys3:part0:1.2 [current_project]
}


# CHANGE DESIGN NAME HERE
variable design_name
set design_name TrabajoPrevio

# If you do not already have an existing IP Integrator design open,
# you can create a design using the following command:
#    create_bd_design $design_name

# Creating design if needed
set errMsg ""
set nRet 0

set cur_design [current_bd_design -quiet]
set list_cells [get_bd_cells -quiet]

if { ${design_name} eq "" } {
   # USE CASES:
   #    1) Design_name not set

   set errMsg "Please set the variable <design_name> to a non-empty value."
   set nRet 1

} elseif { ${cur_design} ne "" && ${list_cells} eq "" } {
   # USE CASES:
   #    2): Current design opened AND is empty AND names same.
   #    3): Current design opened AND is empty AND names diff; design_name NOT in project.
   #    4): Current design opened AND is empty AND names diff; design_name exists in project.

   if { $cur_design ne $design_name } {
      common::send_gid_msg -ssname BD::TCL -id 2001 -severity "INFO" "Changing value of <design_name> from <$design_name> to <$cur_design> since current design is empty."
      set design_name [get_property NAME $cur_design]
   }
   common::send_gid_msg -ssname BD::TCL -id 2002 -severity "INFO" "Constructing design in IPI design <$cur_design>..."

} elseif { ${cur_design} ne "" && $list_cells ne "" && $cur_design eq $design_name } {
   # USE CASES:
   #    5) Current design opened AND has components AND same names.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 1
} elseif { [get_files -quiet ${design_name}.bd] ne "" } {
   # USE CASES: 
   #    6) Current opened design, has components, but diff names, design_name exists in project.
   #    7) No opened design, design_name exists in project.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 2

} else {
   # USE CASES:
   #    8) No opened design, design_name not in project.
   #    9) Current opened design, has components, but diff names, design_name not in project.

   common::send_gid_msg -ssname BD::TCL -id 2003 -severity "INFO" "Currently there is no design <$design_name> in project, so creating one..."

   create_bd_design $design_name

   common::send_gid_msg -ssname BD::TCL -id 2004 -severity "INFO" "Making design <$design_name> as current_bd_design."
   current_bd_design $design_name

}

common::send_gid_msg -ssname BD::TCL -id 2005 -severity "INFO" "Currently the variable <design_name> is equal to \"$design_name\"."

if { $nRet != 0 } {
   catch {common::send_gid_msg -ssname BD::TCL -id 2006 -severity "ERROR" $errMsg}
   return $nRet
}

##################################################################
# DESIGN PROCs
##################################################################



# Procedure to create entire design; Provide argument to make
# procedure reusable. If parentCell is "", will use root.
proc create_root_design { parentCell } {

  variable script_folder
  variable design_name

  if { $parentCell eq "" } {
     set parentCell [get_bd_cells /]
  }

  # Get object for parentCell
  set parentObj [get_bd_cells $parentCell]
  if { $parentObj == "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2090 -severity "ERROR" "Unable to find parent cell <$parentCell>!"}
     return
  }

  # Make sure parentObj is hier blk
  set parentType [get_property TYPE $parentObj]
  if { $parentType ne "hier" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2091 -severity "ERROR" "Parent <$parentObj> has TYPE = <$parentType>. Expected to be <hier>."}
     return
  }

  # Save current instance; Restore later
  set oldCurInst [current_bd_instance .]

  # Set parent object as current
  current_bd_instance $parentObj


  # Create interface ports

  # Create ports
  set JA1 [ create_bd_port -dir O JA1 ]
  set JB1 [ create_bd_port -dir I JB1 ]
  set an [ create_bd_port -dir O -from 3 -to 0 an ]
  set clk [ create_bd_port -dir I clk ]
  set dp [ create_bd_port -dir O dp ]
  set seg [ create_bd_port -dir O -from 6 -to 0 seg ]
  set sw0 [ create_bd_port -dir I sw0 ]
  set sw1 [ create_bd_port -dir I sw1 ]
  set sw2 [ create_bd_port -dir I sw2 ]

  # Create instance: RX_uart_0, and set properties
  set block_name RX_uart
  set block_cell_name RX_uart_0
  if { [catch {set RX_uart_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $RX_uart_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: comparador_0, and set properties
  set block_name comparador
  set block_cell_name comparador_0
  if { [catch {set comparador_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $comparador_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: display_interface_0, and set properties
  set block_name display_interface
  set block_cell_name display_interface_0
  if { [catch {set display_interface_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $display_interface_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: display_manager_0, and set properties
  set block_name display_manager
  set block_cell_name display_manager_0
  if { [catch {set display_manager_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $display_manager_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: divisor_de_clk_con_s_0, and set properties
  set block_name divisor_de_clk_con_switch
  set block_cell_name divisor_de_clk_con_s_0
  if { [catch {set divisor_de_clk_con_s_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $divisor_de_clk_con_s_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: divisor_de_clk_displ_0, and set properties
  set block_name divisor_de_clk_display
  set block_cell_name divisor_de_clk_displ_0
  if { [catch {set divisor_de_clk_displ_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $divisor_de_clk_displ_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: divisor_de_clk_sierra_0, and set properties
  set block_name divisor_de_clk_sierra
  set block_cell_name divisor_de_clk_sierra_0
  if { [catch {set divisor_de_clk_sierra_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $divisor_de_clk_sierra_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: divisor_de_clk_uart_0, and set properties
  set block_name divisor_de_clk_uart
  set block_cell_name divisor_de_clk_uart_0
  if { [catch {set divisor_de_clk_uart_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $divisor_de_clk_uart_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: generador_de_sierra_0, and set properties
  set block_name generador_de_sierra
  set block_cell_name generador_de_sierra_0
  if { [catch {set generador_de_sierra_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $generador_de_sierra_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: generador_de_sinusoi_0, and set properties
  set block_name generador_de_sinusoide
  set block_cell_name generador_de_sinusoi_0
  if { [catch {set generador_de_sinusoi_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $generador_de_sinusoi_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: wave_mux_0, and set properties
  set block_name wave_mux
  set block_cell_name wave_mux_0
  if { [catch {set wave_mux_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $wave_mux_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create port connections
  connect_bd_net -net RX_uart_0_wave_out [get_bd_pins RX_uart_0/wave_out] [get_bd_pins wave_mux_0/music]
  connect_bd_net -net clk_1 [get_bd_ports clk] [get_bd_pins divisor_de_clk_con_s_0/clk_in] [get_bd_pins divisor_de_clk_displ_0/clk_in] [get_bd_pins divisor_de_clk_sierra_0/clk_in] [get_bd_pins divisor_de_clk_uart_0/clk_in]
  connect_bd_net -net comparador_0_comparacion [get_bd_ports JA1] [get_bd_pins comparador_0/comparacion]
  connect_bd_net -net display_interface_0_an [get_bd_ports an] [get_bd_pins display_interface_0/an]
  connect_bd_net -net display_interface_0_dp [get_bd_ports dp] [get_bd_pins display_interface_0/dp]
  connect_bd_net -net display_interface_0_seg [get_bd_ports seg] [get_bd_pins display_interface_0/seg]
  connect_bd_net -net display_manager_0_decimal_point [get_bd_pins display_interface_0/decimal_point] [get_bd_pins display_manager_0/decimal_point]
  connect_bd_net -net display_manager_0_digit_index [get_bd_pins display_interface_0/digit_index] [get_bd_pins display_manager_0/digit_index]
  connect_bd_net -net display_manager_0_digit_value [get_bd_pins display_interface_0/digit_value] [get_bd_pins display_manager_0/digit_value]
  connect_bd_net -net divisor_de_clk_con_s_0_clk_out [get_bd_pins divisor_de_clk_con_s_0/clk_out] [get_bd_pins generador_de_sinusoi_0/clk]
  connect_bd_net -net divisor_de_clk_con_s_0_clk_out_disp_freq [get_bd_pins display_manager_0/digits] [get_bd_pins divisor_de_clk_con_s_0/clk_out_disp_freq]
  connect_bd_net -net divisor_de_clk_displ_0_clk_out [get_bd_pins display_manager_0/display_update_rate_clk] [get_bd_pins divisor_de_clk_displ_0/clk_out]
  connect_bd_net -net divisor_de_clk_sierra_0_clk_out [get_bd_pins divisor_de_clk_sierra_0/clk_out] [get_bd_pins generador_de_sierra_0/clk]
  connect_bd_net -net divisor_de_clk_uart_0_clk_out [get_bd_pins RX_uart_0/baud_rate_clk] [get_bd_pins divisor_de_clk_uart_0/clk_out]
  connect_bd_net -net generador_de_sierra_0_sierra [get_bd_pins comparador_0/positivo] [get_bd_pins generador_de_sierra_0/sierra]
  connect_bd_net -net generador_de_sinusoi_0_sinusoide [get_bd_pins generador_de_sinusoi_0/sinusoide] [get_bd_pins wave_mux_0/sinusoid]
  connect_bd_net -net sw0_1 [get_bd_ports sw0] [get_bd_pins divisor_de_clk_con_s_0/sw0]
  connect_bd_net -net sw1_1 [get_bd_ports sw1] [get_bd_pins divisor_de_clk_con_s_0/sw1]
  connect_bd_net -net sw_0_1 [get_bd_ports sw2] [get_bd_pins wave_mux_0/sw]
  connect_bd_net -net uart_rx_in_0_1 [get_bd_ports JB1] [get_bd_pins RX_uart_0/uart_rx_in]
  connect_bd_net -net wave_mux_0_wave_out [get_bd_pins comparador_0/negativo] [get_bd_pins wave_mux_0/wave_out]

  # Create address segments


  # Restore current instance
  current_bd_instance $oldCurInst

  validate_bd_design
  save_bd_design
}
# End of create_root_design()


##################################################################
# MAIN FLOW
##################################################################

create_root_design ""


